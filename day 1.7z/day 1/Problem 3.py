a=int(input("enter a="))
b=int(input("enter b="))
print("before swaping the value of a =",a)
print("and the value of b=",b)
a=a+b
b=a-b
a=a-b
print("after swaping the value of a=",a)
print("and the value of b=",b)