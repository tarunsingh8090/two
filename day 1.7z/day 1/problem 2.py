n=float(input("enter a number:"))
s=n**0.5
print("square root of" ,n,"is",s)